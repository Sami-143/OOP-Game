﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game.GameGL
{
    enum GameObjectType
    {
        WALL,
        PLAYER,
        ENEMY,
        HENEMY,
        VENEMY,
        RENEMY,
        REWARD,
        BULLET,
        HEART,
        NONE
    }
}
