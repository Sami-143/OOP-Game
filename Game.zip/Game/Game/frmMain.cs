﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EZInput;
using Game.GameGL;

namespace Game
{
    public partial class Form1 : Form
    {
        GameThings game;
        int timer;
        public Form1()
        {
            InitializeComponent();
            game = new GameThings(this);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lblThomasHealth.Location = new System.Drawing.Point(256, 630);
            lblThomasHealthNumber.Location = new System.Drawing.Point(441, 630);
            lblThomasScore.Location = new System.Drawing.Point(47, 630);
            lblThomasScoreNumber.Location = new System.Drawing.Point(156, 630);
            VerticalEnemy vertical = new VerticalEnemy(ImageGiver.getVerticalPoliceImage(), game.getCell(3, 32));
            VerticalEnemy vertical1 = new VerticalEnemy(ImageGiver.getVerticalPoliceImage(), game.getCell(10, 10));
            RandomEnemy random = new RandomEnemy(ImageGiver.getRandomPoliceImage(), game.getCell(8,14 ));
            RandomEnemy random1 = new RandomEnemy(ImageGiver.getRandomPoliceImage(), game.getCell(15,36));
            HorizontalEnemy horizontal = new HorizontalEnemy(ImageGiver.getHorizontalPoliceImage(), game.getCell(6, 38));   
            game.addEnemyInList(vertical);
            game.addEnemyInList(vertical1);
            game.addEnemyInList(random);
            game.addEnemyInList(random1);
            game.addEnemyInList(horizontal);
        }

        private void gameLoop_Tick(object sender, EventArgs e)
        {
            GamePlayer player = game.getPlayer();
            GameCell potentialNewCell = player.CurrentCell;
            if (Keyboard.IsKeyPressed(Key.LeftArrow))
            {
                potentialNewCell = player.CurrentCell.nextCell(GameDirection.Left);
            }
            if (Keyboard.IsKeyPressed(Key.RightArrow))
            {
                potentialNewCell = player.CurrentCell.nextCell(GameDirection.Right);
            }
            if (Keyboard.IsKeyPressed(Key.UpArrow))
            {
                potentialNewCell = player.CurrentCell.nextCell(GameDirection.Up);
            }
            if (Keyboard.IsKeyPressed(Key.DownArrow))
            {
                potentialNewCell = player.CurrentCell.nextCell(GameDirection.Down);
            }
            if (Keyboard.IsKeyPressed(Key.Space))
            {
                player.generateBullet();
            }
            if(potentialNewCell.CurrentGameObject.GameObjectType == GameObjectType.HEART)
            {
                GameThings.decreasePlayerHealth(-1);
            }
            GameCell currentCell = player.CurrentCell;
            currentCell.setGameObject(ImageGiver.getBlankGameObject());
            player.move(potentialNewCell);
            isGameOver();
            game.Timer();
            player.moveBullets();
            
            game.produceHeartRandomly();
            
        }

        private void bulletLoop_Tick(object sender, EventArgs e)
        {          
            foreach (var i in game.GetEnemies())
            {
                i.move(i.nextCell());
                if (game.getTimer() % 10 == 0)
                {
                    i.generateBullet();
                }
                i.moveBullets();
            }
            lblThomasScoreNumber.Text = game.getScore().ToString();
            lblThomasHealthNumber.Text = game.getPlayerHealth().ToString();
        }

        private void isGameOver()
        {
            if(game.getPlayerHealth() <= 0)
            {
                GameLoop.Enabled = false;
                bulletLoop.Enabled = false;
                MessageBox.Show("Game Over");
                this.Close();
            }
        }

        private void isHorizontalDestroyed()
        {
            
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            
        }

        
    }
}
